package com.example.meditation1

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat



class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val menu = findViewById<ImageView?>(R.id.btn_sidemenu) //инициализация кнопок
        val profile = findViewById<ImageView?>(R.id.btn_profile)
        val profilepic = findViewById<ImageView>(R.id.btn_profilepic)
        val sounds = findViewById<ImageView?>(R.id.btn_sounds);
        var ind =0;

        ind=1
        menu.setOnClickListener {//переход в меню
            val intent: Intent = Intent(this, Menu::class.java)
            startActivity(intent)
        }

        profile.setOnClickListener{//Переход в профиль
            val intent: Intent = Intent(this, Profile::class.java)
            startActivity(intent)
        }
        profilepic.setOnClickListener{//Переход в профиль
            val intent: Intent = Intent(this, Profile::class.java)
            startActivity(intent)
        }

        sounds.setOnClickListener {//переход к аудиозаписям
            val intent: Intent = Intent(this, Listen::class.java)
            startActivity(intent)
        }
    }
}