package com.example.meditation1

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Onboarding : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_onboarding)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val login = findViewById<Button>(R.id.btn_login) //инициализация кнопок
        val registration = findViewById<TextView>(R.id.btn_registration)

        login.setOnClickListener{ //Переход к окну входа
            val intent: Intent = Intent(this, Login::class.java)
            startActivity(intent)
        }

        registration.setOnClickListener{ //Переход к регистрации
            val intent: Intent = Intent(this, Register::class.java)
            startActivity(intent)
        }
    }
}